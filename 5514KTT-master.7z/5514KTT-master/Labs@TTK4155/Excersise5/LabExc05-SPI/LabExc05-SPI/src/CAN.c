/*
 * CAN.c
 *
 * Created: 21.10.2014 14:05:43
 *  Author: sveigri
 */ 

#pragma once

#include "CAN.h"
#include "MCP2515.h"





void can_init(uint8_t mode)
{
	mcp2515_reset();
	
	mcp2515_write(MCP_CANCTRL, mode);
	//mcp2515_bit_modify(MCP_CANCTRL,MODE_MASK,mode);
	
	if ((mcp2515_read(MCP_CANSTAT) & MODE_MASK) != mode) 
	{
		printf("\n\r0x%02x", mcp2515_read(MCP_CANSTAT));
		printf("\r\nLoopBack disabled");
	}
	else
	
		printf("\r\nLoopBack enabled");
	
}

void can_message_send(can_message_t *message)
{
	uint8_t length = message ->length;
	
	// setting id, 11 id bits
	mcp2515_write(MCP_TXB0SIDH, (uint8_t) (message->id>>3));
	mcp2515_write(MCP_TXB0SIDL, (uint8_t) (message->id<<5));
	
	// setting data length code
	mcp2515_write(MCP_TXB0DLC, length);
	
	// setting data
	for (uint8_t i=0;i<length;i++) 
	{
		mcp2515_write(MCP_TXB0D0 + i, message->data[i]);
	}
	
	// send message
	mcp2515_rts(0x01);
	
}