/*
 * MCP2515.c
 *
 * Created: 21.10.2014 13:11:31
 *  Author: sveigri
 */ 

#pragma once

#include "MCP2515.h"

void mcp2515_write(uint8_t address, uint8_t data)
{
	spiSlaveSelect();
	
	spi_putc(MCP_WRITE); //write
	spi_putc(address);
	spi_putc(data);
	
	spiSlaveDeselect();
}

uint8_t mcp2515_read(uint8_t address)
{
	uint8_t data_in;
	spiSlaveSelect();
	
	spi_putc(MCP_READ); //read
	spi_putc(address);
	
	data_in = spi_putc(0xff); // send junk
	
	spiSlaveDeselect();
}

void mcp2515_reset(void)
{
	spiSlaveSelect();
	
	spi_putc(MCP_RESET); // reset
	
	spiSlaveDeselect();
}

void mcp2515_bit_modify(uint8_t address, uint8_t mask, uint8_t data)
{
	spiSlaveSelect();
	
	spi_putc(MCP_BITMOD); // bit modify
	spi_putc(address);
	spi_putc(mask);
	spi_putc(data);
	
	spiSlaveDeselect();
}

uint8_t mcp2515_read_status(void)
{
	uint8_t data_in;
	
	spiSlaveSelect();
	
	spi_putc(MCP_READ_STATUS); // read status
	data_in = spi_putc(0xff); // send junk
	
	
	spiSlaveDeselect();
	
	return data_in;
}


void mcp2515_rts(uint8_t nnn)
{
	uint8_t rts = 0x80;
	
	if(nnn < 8){
		rts |= nnn;
	}
	
	spiSlaveSelect();
	spi_putc(rts);
	spiSlaveDeselect();
}