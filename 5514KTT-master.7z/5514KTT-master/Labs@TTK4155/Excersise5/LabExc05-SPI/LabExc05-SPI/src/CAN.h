/*
 * CAN.h
 *
 * Created: 21.10.2014 14:05:55
 *  Author: sveigri
 */ 


#ifndef CAN_H_
#define CAN_H_

/*DEFINITIONS/CONFIG*/
//---------------//Define CPU frequency

/*Global constants*/
//extern const var variable

/*header files*/
#include <asf.h>
//#include <stdlib.h>
#include <stdio.h>
#include <avr/io.h>
//#include <avr/interrupt.h>
//#include <util/delay.h>
//#include <EEPROM.h>

/*header files*/

//thing
typedef struct
{
	unsigned int id;
	uint8_t length;
	uint8_t data[8];
	
}can_message_t;


/*Function Declarations*/

void can_init(uint8_t mode);
void can_message_send(can_message_t *message);

#endif /* CAN_H_ */