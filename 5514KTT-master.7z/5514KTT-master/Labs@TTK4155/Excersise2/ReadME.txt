DIRECTORY CONTENT:
------------------

Labs@TTK4155\Excersise2\ispLEVER\
|----[*]Contains ispLEVER project for GAL[...] logic IC. IC to act as a chip selector in TTK4155 circuit...
Labs@TTK4155\Excersise2\ispLEVER\
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Labs@TTK4155\Excersise2\LabExc02-XMEM\
|----[*]Atmel Studio project folder